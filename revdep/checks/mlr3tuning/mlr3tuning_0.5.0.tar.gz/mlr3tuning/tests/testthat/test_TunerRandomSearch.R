test_that("TunerRandomSearch", {
  test_tuner("random_search")
  test_tuner_dependencies("random_search")
})
