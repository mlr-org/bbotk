test_that("TunerCmaes", {
  test_tuner("cmaes", par = 0.3)
})
