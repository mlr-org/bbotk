library(testthat)
library(mlr3)
library(mlr3fselect)
library(checkmate)

test_check("mlr3fselect")
