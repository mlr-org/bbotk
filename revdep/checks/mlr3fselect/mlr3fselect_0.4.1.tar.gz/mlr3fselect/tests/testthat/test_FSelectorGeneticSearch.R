context("FSelectorGeneticSearch")

test_that("FSelectorGeneticSearch", {
  test_fselector("genetic_search", term_evals = 10, real_evals = 10)
})
